﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
namespace EShopping.User
{
public partial class Aboutus : System.Web.UI.Page  //
 //Defines Aboutus web page class
{/**/
protected void Page_Load(object sender, EventArgs e)//
//Handles page load event
{/**/
// Method body is empty
}/**/
}  // Class definition ends/**/
}/**/